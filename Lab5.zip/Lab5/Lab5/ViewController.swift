import UIKit

class HomeViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    let cardView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor(red: 0.96, green: 0.96, blue: 0.96, alpha: 1.0)
        view.layer.cornerRadius = 20
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOpacity = 0.3
        view.layer.shadowOffset = CGSize(width: 0, height: 2)
        view.layer.shadowRadius = 4
        return view
    }()
    
    let cardNumberLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor(red: 0.1, green: 0.1, blue: 0.1, alpha: 1.0)
        label.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        return label
    }()
    
    let cardHolderLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor(red: 0.2, green: 0.2, blue: 0.2, alpha: 1.0)
        label.font = UIFont.systemFont(ofSize: 16)
        return label
    }()
    
    let expiryDateLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor(red: 0.2, green: 0.2, blue: 0.2, alpha: 1.0)
        label.font = UIFont.systemFont(ofSize: 16)
        return label
    }()
    
    let cardTypeImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    let bankLogoImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    let tableView: UITableView = {
        let tableView = UITableView()
        tableView.backgroundColor = .clear
        tableView.layer.cornerRadius = 20
        tableView.clipsToBounds = true
        tableView.separatorStyle = .none
        return tableView
    }()
    
    let recentPurchasesData = ["Item 1", "Item 2", "Item 3"]
    let recentTransfersData = ["Transfer 1", "Transfer 2", "Transfer 3"]
    let recentDepositsData = ["Deposit 1", "Deposit 2", "Deposit 3"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = UIColor(red: 0.9, green: 0.9, blue: 0.9, alpha: 1.0)
        
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        
        // Add subviews
        view.addSubview(cardView)
        cardView.addSubview(cardNumberLabel)
        cardView.addSubview(cardHolderLabel)
        cardView.addSubview(expiryDateLabel)
        cardView.addSubview(cardTypeImageView)
        cardView.addSubview(bankLogoImageView)
        view.addSubview(tableView)
        
        // Constraints
        cardView.translatesAutoresizingMaskIntoConstraints = false
        cardNumberLabel.translatesAutoresizingMaskIntoConstraints = false
        cardHolderLabel.translatesAutoresizingMaskIntoConstraints = false
        expiryDateLabel.translatesAutoresizingMaskIntoConstraints = false
        cardTypeImageView.translatesAutoresizingMaskIntoConstraints = false
        bankLogoImageView.translatesAutoresizingMaskIntoConstraints = false
        tableView.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            cardView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            cardView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            cardView.widthAnchor.constraint(equalToConstant: 320),
            cardView.heightAnchor.constraint(equalToConstant: 200),
            
            cardNumberLabel.topAnchor.constraint(equalTo: cardView.topAnchor, constant: 20),
            cardNumberLabel.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 20),
            
            cardHolderLabel.topAnchor.constraint(equalTo: cardNumberLabel.bottomAnchor, constant: 10),
            cardHolderLabel.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 20),
            
            expiryDateLabel.bottomAnchor.constraint(equalTo: cardView.bottomAnchor, constant: -20),
            expiryDateLabel.trailingAnchor.constraint(equalTo: cardView.trailingAnchor, constant: -20),
            
            cardTypeImageView.topAnchor.constraint(equalTo: cardView.topAnchor, constant: 20),
            cardTypeImageView.trailingAnchor.constraint(equalTo: cardView.trailingAnchor, constant: -20),
            cardTypeImageView.widthAnchor.constraint(equalToConstant: 50),
            cardTypeImageView.heightAnchor.constraint(equalToConstant: 30),
            
            bankLogoImageView.bottomAnchor.constraint(equalTo: cardView.bottomAnchor, constant: -20),
            bankLogoImageView.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 20),
            bankLogoImageView.widthAnchor.constraint(equalToConstant: 80),
            bankLogoImageView.heightAnchor.constraint(equalToConstant: 30),
            
            tableView.topAnchor.constraint(equalTo: cardView.bottomAnchor, constant: 20),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            tableView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20)
        ])
        
        // Dummy data
        cardNumberLabel.text = "1234 5678 9012 3456"
        cardHolderLabel.text = "John Doe"
        expiryDateLabel.text = "Exp: 12/25"
        if let visaImage = UIImage(contentsOfFile: "/Users/nocturneflow/Downloads/Lab5/Lab5/visa_logo.png") {
            cardTypeImageView.image = visaImage
        } else {
            print("Failed to load Visa image from path")
        }

        if let bankImage = UIImage(contentsOfFile: "/Users/nocturneflow/Downloads/Lab5/Lab5/bank_logo.png") {
            bankLogoImageView.image = bankImage
        } else {
            print("Failed to load bank image from path")
        }
    }
    
    // MARK: - UITableViewDataSource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0:
            return recentPurchasesData.count
        case 1:
            return recentTransfersData.count
        case 2:
            return recentDepositsData.count
        default:
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        switch indexPath.section {
        case 0:
            cell.textLabel?.text = recentPurchasesData[indexPath.row]
        case 1:
            cell.textLabel?.text = recentTransfersData[indexPath.row]
        case 2:
            cell.textLabel?.text = recentDepositsData[indexPath.row]
        default:
            break
        }
        
        cell.contentView.layer.cornerRadius = 20
        cell.contentView.layer.masksToBounds = true
        
        return cell
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        switch section {
        case 0:
            return "Purchases"
        case 1:
            return "Transfers"
        case 2:
            return "Deposits"
        default:
            return nil
        }
    }
}

// Usage
let homeViewController = HomeViewController()
// Present or push homeViewController to display the home page.
