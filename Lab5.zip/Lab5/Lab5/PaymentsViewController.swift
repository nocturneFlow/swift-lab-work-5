import UIKit

class PaymentsViewController: UIViewController {
    
    let titleLabel: UILabel = {
        let label = UILabel()
        label.text = "Choose Payment Option"
        label.font = UIFont.systemFont(ofSize: 24, weight: .semibold)
        label.textAlignment = .center
        label.textColor = .black
        return label
    }()
    
    let taxButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Pay Tax", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 18, weight: .regular)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = UIColor(red: 0.00, green: 0.51, blue: 0.25, alpha: 1.00)
        button.layer.cornerRadius = 8
        button.addTarget(self, action: #selector(taxButtonTapped), for: .touchUpInside)
        return button
    }()
    
    let internetButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Pay Internet Bill", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 18, weight: .regular)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = UIColor(red: 0.00, green: 0.33, blue: 0.67, alpha: 1.00)
        button.layer.cornerRadius = 8
        button.addTarget(self, action: #selector(internetButtonTapped), for: .touchUpInside)
        return button
    }()
    
    let electricityButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Pay Electricity Bill", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 18, weight: .regular)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = UIColor(red: 0.85, green: 0.22, blue: 0.10, alpha: 1.00)
        button.layer.cornerRadius = 8
        button.addTarget(self, action: #selector(electricityButtonTapped), for: .touchUpInside)
        return button
    }()
    
    let rentButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Pay Rent", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 18, weight: .regular)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = UIColor(red: 0.75, green: 0.45, blue: 0.10, alpha: 1.00)
        button.layer.cornerRadius = 8
        button.addTarget(self, action: #selector(rentButtonTapped), for: .touchUpInside)
        return button
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 0.95, green: 0.95, blue: 0.95, alpha: 1.00)
        setupUI()
    }
    
    func setupUI() {
        view.addSubview(titleLabel)
        view.addSubview(taxButton)
        view.addSubview(internetButton)
        view.addSubview(electricityButton)
        view.addSubview(rentButton)
        
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        taxButton.translatesAutoresizingMaskIntoConstraints = false
        internetButton.translatesAutoresizingMaskIntoConstraints = false
        electricityButton.translatesAutoresizingMaskIntoConstraints = false
        rentButton.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            titleLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 40),
            titleLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            titleLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            
            taxButton.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 40),
            taxButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            taxButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            taxButton.heightAnchor.constraint(equalToConstant: 60),
            
            internetButton.topAnchor.constraint(equalTo: taxButton.bottomAnchor, constant: 20),
            internetButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            internetButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            internetButton.heightAnchor.constraint(equalToConstant: 60),
            
            electricityButton.topAnchor.constraint(equalTo: internetButton.bottomAnchor, constant: 20),
            electricityButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            electricityButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            electricityButton.heightAnchor.constraint(equalToConstant: 60),
            
            rentButton.topAnchor.constraint(equalTo: electricityButton.bottomAnchor, constant: 20),
            rentButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            rentButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            rentButton.heightAnchor.constraint(equalToConstant: 60)
        ])
    }
    
    @objc func taxButtonTapped() {
        // Handle tax payment logic here
        print("Tax payment initiated.")
        
        let taxPaymentViewController = TaxPaymentViewController()
        let navController = UINavigationController(rootViewController: taxPaymentViewController)
        navController.modalPresentationStyle = .fullScreen
        present(navController, animated: true, completion: nil)
    }
    
    @objc func internetButtonTapped() {
        // Handle internet bill payment logic here
        print("Internet bill payment initiated.")
    }
    
    @objc func electricityButtonTapped() {
        // Handle electricity bill payment logic here
        print("Electricity bill payment initia ted.")
    }
    
    @objc func rentButtonTapped() {
        // Handle rent payment logic here
        print("Rent payment initiated.")
    }
}
