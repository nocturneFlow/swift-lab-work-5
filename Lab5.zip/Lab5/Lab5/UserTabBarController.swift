import UIKit

class UserTabBarController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        configureTabs()
    }
    
    private func configureTabs(){
        let vc1 = HomeViewController()
        let vc2 = PaymentsViewController()
        let vc3 = ExpenseViewController()
        
        // For vc1
        vc1.tabBarItem.image = UIImage(systemName: "house")

        // For vc2
        vc2.tabBarItem.image = UIImage(systemName: "dollarsign.square.fill")

        // For vc3
        vc3.tabBarItem.image = UIImage(systemName: "person.fill")

        
        vc1.tabBarItem.title = "Home"
        vc1.title = "Home"
        vc2.tabBarItem.title = "Payment"
        vc2.title = "Payment"
        vc3.tabBarItem.title = "Expenses"
        vc3.title = "Expenses"
        
        let nav1 = UINavigationController(rootViewController: vc1)
        let nav2 = UINavigationController(rootViewController: vc2)
        let nav3 = UINavigationController(rootViewController: vc3)

        tabBar.tintColor = .label
        tabBar.backgroundColor = .systemGray6
        
        setViewControllers([nav1, nav2, nav3], animated: true)

    }

}
