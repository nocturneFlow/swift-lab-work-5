import UIKit

struct Expense {
    let title: String
    let amount: Double
    let category: String
}

class ExpenseViewController: UIViewController {
    
    // Dummy expense data
    let expenses: [Expense] = [
        Expense(title: "Groceries", amount: 50.0, category: "Food"),
        Expense(title: "Movie tickets", amount: 20.0, category: "Entertainment"),
        Expense(title: "Dinner", amount: 80.0, category: "Food"),
        Expense(title: "Transportation", amount: 30.0, category: "Travel"),
        Expense(title: "Books", amount: 25.0, category: "Education"),
        Expense(title: "Clothing", amount: 70.0, category: "Shopping"),
        Expense(title: "Gym membership", amount: 50.0, category: "Fitness"),
        Expense(title: "Utilities", amount: 100.0, category: "Bills"),
        Expense(title: "Eating out", amount: 40.0, category: "Food"),
        Expense(title: "Mobile phone bill", amount: 45.0, category: "Bills"),
        Expense(title: "Home maintenance", amount: 150.0, category: "Household")
    ]

    
    // UI components
    let tableView = UITableView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Expense Tracker"
        view.backgroundColor = .white
        
        // Setup table view
        tableView.frame = view.bounds
        tableView.dataSource = self
        tableView.register(ExpenseTableViewCell.self, forCellReuseIdentifier: "ExpenseCell")
        view.addSubview(tableView)
    }
}

extension ExpenseViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return expenses.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ExpenseCell", for: indexPath) as! ExpenseTableViewCell
        let expense = expenses[indexPath.row]
        cell.titleLabel.text = expense.title
        cell.amountLabel.text = "$\(expense.amount)"
        cell.categoryLabel.text = expense.category
        return cell
    }
}

class ExpenseTableViewCell: UITableViewCell {
    
    let titleLabel = UILabel()
    let amountLabel = UILabel()
    let categoryLabel = UILabel()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        titleLabel.font = UIFont.boldSystemFont(ofSize: 16)
        amountLabel.font = UIFont.systemFont(ofSize: 14)
        categoryLabel.font = UIFont.italicSystemFont(ofSize: 12)
        
        let stackView = UIStackView(arrangedSubviews: [titleLabel, amountLabel, categoryLabel])
        stackView.axis = .vertical
        stackView.spacing = 5
        stackView.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(stackView)
        
        NSLayoutConstraint.activate([
            stackView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            stackView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),
            stackView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 10),
            stackView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -10)
        ])
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

