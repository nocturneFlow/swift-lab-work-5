import UIKit

class TaxPaymentViewController: UIViewController {
    
    let confirmationLabel: UILabel = {
        let label = UILabel()
        label.text = "Tax Payment Confirmation"
        label.font = UIFont.systemFont(ofSize: 24, weight: .semibold)
        label.textAlignment = .center
        label.textColor = .black
        return label
    }()
    
    let clientIDTextField: UITextField = {
        let textField = UITextField()
        textField.placeholder = "Client ID"
        textField.borderStyle = .roundedRect
        return textField
    }()
    
    let addressTextView: UITextView = {
        let textView = UITextView()
        textView.text = "Address"
        textView.font = UIFont.systemFont(ofSize: 16)
        textView.textColor = .black
        textView.layer.borderWidth = 1.0
        textView.layer.borderColor = UIColor.lightGray.cgColor
        textView.layer.cornerRadius = 5.0
        return textView
    }()
    
    let payButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Pay", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = .blue
        button.layer.cornerRadius = 8.0
        button.addTarget(self, action: #selector(payButtonTapped), for: .touchUpInside)
        return button
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupNavigationBar()
        setupUI()
    }
    
    func setupNavigationBar() {
        navigationItem.leftBarButtonItem = UIBarButtonItem(barButtonSystemItem: .cancel, target: self, action: #selector(cancelButtonTapped))
    }
    
    func setupUI() {
        view.addSubview(confirmationLabel)
        view.addSubview(clientIDTextField)
        view.addSubview(addressTextView)
        view.addSubview(payButton)
        
        confirmationLabel.translatesAutoresizingMaskIntoConstraints = false
        clientIDTextField.translatesAutoresizingMaskIntoConstraints = false
        addressTextView.translatesAutoresizingMaskIntoConstraints = false
        payButton.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            confirmationLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 40),
            confirmationLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            confirmationLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            
            clientIDTextField.topAnchor.constraint(equalTo: confirmationLabel.bottomAnchor, constant: 20),
            clientIDTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            clientIDTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            clientIDTextField.heightAnchor.constraint(equalToConstant: 40),
            
            addressTextView.topAnchor.constraint(equalTo: clientIDTextField.bottomAnchor, constant: 20),
            addressTextView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            addressTextView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            addressTextView.heightAnchor.constraint(equalToConstant: 100),
            
            payButton.topAnchor.constraint(equalTo: addressTextView.bottomAnchor, constant: 20),
            payButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            payButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            payButton.heightAnchor.constraint(equalToConstant: 50)
        ])
    }
    
    @objc func payButtonTapped() {
        // Handle payment logic here
    }
    
    @objc func cancelButtonTapped() {
        dismiss(animated: true, completion: nil)
    }
}
